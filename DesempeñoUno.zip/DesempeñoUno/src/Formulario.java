import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import com.sun.security.auth.NTDomainPrincipal;

public class Formulario extends JFrame implements ActionListener {

	private JLabel l1, l2, l3, l4, l5, l6, l7;
	private JTextField tf1;
	private JButton boton1;
	private JMenuBar mb;
	private JMenu menu1, menu2;
	private JMenuItem item1, item2, item3, item4, item5;
	int contador=0;

	public Formulario() {
		setLayout(null);
		mb = new JMenuBar();
		setJMenuBar(mb);
		// FONDO Item 1,2,3
		menu1 = new JMenu("Fondo");
		mb.add(menu1);
		item1 = new JMenuItem("Rojo");
		menu1.add(item1);
		item2 = new JMenuItem("Azul");
		menu1.add(item2);
		item3 = new JMenuItem("Amarillo");
		menu1.add(item3);
		// BOTONES Item 4,5
		menu2 = new JMenu("Botones");
		mb.add(menu2);
		item4 = new JMenuItem("Blanco");
		menu2.add(item4);
		item5 = new JMenuItem("Negro");
		menu2.add(item5);

		item1.addActionListener(this);
		item2.addActionListener(this);
		item3.addActionListener(this);
		item4.addActionListener(this);
		item5.addActionListener(this);

		// ADIVINA EL NUMERO L1
		l1 = new JLabel("Adivina el numero");
		l1.setBounds(200, 10, 150, 30);
		add(l1);
		// ?? L2
		l2 = new JLabel("??");
		l2.setBounds(240, 40, 100, 30);
		add(l2);
		// INTENTO... L3
		l3 = new JLabel("Intento...");
		l3.setBounds(90, 90, 100, 30);
		add(l3);
		// INGRESAR NUMERO
		tf1 = new JTextField();
		tf1.setBounds(180, 90, 150, 20);
		add(tf1);
		// BOTON VALIDAR
		boton1 = new JButton("Validar");
		boton1.setBounds(350, 90, 100, 20);
		add(boton1);
		boton1.addActionListener(this);
		// RESULTADO L4
		l4 = new JLabel("Resultado");
		l4.setBounds(90, 180, 100, 30);
		add(l4);
		// ES MAS GRANDE LABEL INTERMEDIO L5
		l5 = new JLabel("..");
		l5.setBounds(250, 180, 150, 30);
		add(l5);
		// TOTAL INTENTOS L6
		l6 = new JLabel("Total de intentos");
		l6.setBounds(200, 300, 150, 30);
		add(l6);
		// CONTADOR DE INTENTOS
		l7 = new JLabel("::");
		l7.setBounds(340, 300, 100, 30);
		add(l7);

	}

	public static void main(String[] args) {
		Formulario e = new Formulario();
		e.setBounds(0, 0, 600, 500);
		e.setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Container fondo = getContentPane();
		Container bot = getContentPane();

		if (e.getSource() == item1) {
			fondo.setBackground(Color.red);

		}
		if (e.getSource() == item2) {
			fondo.setBackground(Color.blue);

		}
		if (e.getSource() == item3) {
			fondo.setBackground(Color.yellow);

		}
		if (e.getSource() == item4) {
			bot.setBackground(Color.white);

		}
		if (e.getSource() == item5) {
			bot.setBackground(Color.black);

		}
		// VALIDAR BOTON 1
		if (e.getSource() == boton1) {

			int aleatorio = 1 + (int) (Math.random() * 10);
			String s = tf1.getText();
			int valor = Integer.parseInt(s);

			if (aleatorio == valor) {
				l2.setText(String.valueOf(valor));
				l5.setText("Ganaste");

			}
				//CONTADOR
			if (aleatorio != valor) {
				contador++;
				String cont = String.valueOf(contador);
				l7.setText(cont);
			}

			if (aleatorio < valor) {
				l5.setText("Es mas grande");
			}
			if (aleatorio > valor) {
				l5.setText("Es mas chico");
			}

		}
	}
}
